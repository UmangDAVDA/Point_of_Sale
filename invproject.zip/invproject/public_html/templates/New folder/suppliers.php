<!-- Modal -->
<div class="modal fade" id="form_suppliers" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">New Supplier Entry</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
			<form id="suppliers_form" onsubmit="return false">
			  <div class="form-group">
				<label for="exampleInputEmail1">Supplier Name</label>
				<input type="text" class="form-control" id="supplier_name" placeholder="Enter name" name='supplier_name' >
			  </div>
			  <div class="form-group">
				<label for="exampleInputEmail1">Contact Number</label>
				<input type="text" class="form-control" id="supplier_contact_number" placeholder="Enter name" name='supplier_contact_number'>
			  </div>
			  <div class="form-group">
				<label for="exampleInputEmail1">Email Id</label>
				<input type="email" class="form-control" id="supplier_email_id" aria-describedby="emailHelp" placeholder="Enter name" name='supplier_email_id'>
			  </div>
			  <div class="form-group">
				<label for="exampleInputEmail1">Requirement For</label>
				<input type="text" class="form-control" id="supplier_requirement" placeholder="Enter name" name='supplier_requirement'>
			  </div>
			  <div class="form-group">
				<label for="exampleInputEmail1">Quantity</label>
				<input type="text" class="form-control" id="supplier_quantity" placeholder="Enter name" name='supplier_quantity'>
			  </div>
			  <button type="submit" class="btn btn-success">Add Supplier</button>
			</form>
		  </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
    </div>
  </div>
</div>